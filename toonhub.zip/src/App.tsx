import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';

const IMAGES = [
  { src: 'https://fifth-gentle-45902158.figma.site/_components/v2/4de492f6d9cf8244ad5293233e5c6f52407d42fc/1.02464a56.png', bg: '#F4845F', panel: '#F79B7F' },
  { src: 'https://fifth-gentle-45902158.figma.site/_components/v2/4de492f6d9cf8244ad5293233e5c6f52407d42fc/2.b977faab.png', bg: '#6BBF7A', panel: '#85CC92' },
  { src: 'https://fifth-gentle-45902158.figma.site/_components/v2/4de492f6d9cf8244ad5293233e5c6f52407d42fc/3.4df853b4.png', bg: '#E882B4', panel: '#ED9DC4' },
  { src: 'https://fifth-gentle-45902158.figma.site/_components/v2/4de492f6d9cf8244ad5293233e5c6f52407d42fc/4.4457fbce.png', bg: '#6EB5FF', panel: '#8DC4FF' },
];

export default function App() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Preload all 4 images on mount
  useEffect(() => {
    IMAGES.forEach((item) => {
      const img = new Image();
      img.src = item.src;
    });
  }, []);

  // Update isMobile on resize
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 640);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Navigation logic with animation lock (650ms)
  const navigate = useCallback((direction: 'next' | 'prev') => {
    if (isAnimating) return;
    setIsAnimating(true);

    setActiveIndex((prev) => {
      if (direction === 'next') {
        return (prev + 1) % 4;
      } else {
        return (prev + 3) % 4;
      }
    });

    const timer = setTimeout(() => {
      setIsAnimating(false);
    }, 650);

    return () => clearTimeout(timer);
  }, [isAnimating]);

  // Support Arrow keys for seamless accessibility navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        navigate('prev');
      } else if (e.key === 'ArrowRight') {
        navigate('next');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [navigate]);

  // Helper to retrieve roles and positional styles matching "Artistic Flair" theme constraints
  const getRoleStyles = (index: number) => {
    const center = activeIndex;
    const left = (activeIndex + 3) % 4;
    const right = (activeIndex + 1) % 4;

    const transition = 'transform 650ms cubic-bezier(0.4, 0, 0.2, 1), filter 650ms cubic-bezier(0.4, 0, 0.2, 1), opacity 650ms cubic-bezier(0.4, 0, 0.2, 1), left 650ms cubic-bezier(0.4, 0, 0.2, 1), bottom 650ms cubic-bezier(0.4, 0, 0.2, 1), height 650ms cubic-bezier(0.4, 0, 0.2, 1)';

    if (index === center) {
      return {
        transform: `translateX(-50%) scale(${isMobile ? 1.25 : 1.68})`,
        filter: 'blur(0px) drop-shadow(0 25px 25px rgba(0, 0, 0, 0.22))',
        opacity: 1,
        zIndex: 20,
        left: '50%',
        height: isMobile ? '60%' : '92%',
        bottom: isMobile ? '22%' : '0',
        transition,
        willChange: 'transform, filter, opacity',
      };
    } else if (index === left) {
      return {
        transform: 'translateX(-50%) scale(1)',
        filter: 'blur(2px)',
        opacity: 0.85,
        zIndex: 10,
        left: isMobile ? '20%' : '30%',
        height: isMobile ? '16%' : '28%',
        bottom: isMobile ? '32%' : '12%',
        transition,
        willChange: 'transform, filter, opacity',
      };
    } else if (index === right) {
      return {
        transform: 'translateX(-50%) scale(1)',
        filter: 'blur(2px)',
        opacity: 0.85,
        zIndex: 10,
        left: isMobile ? '80%' : '70%',
        height: isMobile ? '16%' : '28%',
        bottom: isMobile ? '32%' : '12%',
        transition,
        willChange: 'transform, filter, opacity',
      };
    } else {
      // back role - styled beautifully for deep backdrop layers
      return {
        transform: 'translateX(-50%) scale(1)',
        filter: 'blur(4px)',
        opacity: 0.70, // 70% opacity in "Artistic Flair"
        zIndex: 5,
        left: '50%',
        height: isMobile ? '13%' : '22%',
        bottom: isMobile ? '32%' : '12%',
        transition,
        willChange: 'transform, filter, opacity',
      };
    }
  };

  // Base64-encoded SVG noise generator to support offline and safe URL rendering in any iFrame context.
  const svgString = `<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='noise'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(#noise)' opacity='0.08'/></svg>`;
  const base64Svg = typeof window !== 'undefined' ? btoa(svgString) : '';
  const grainBackground = `url("data:image/svg+xml;base64,${base64Svg}")`;

  return (
    <div
      id="toonhub-hero"
      className="relative w-full overflow-hidden text-white select-none bg-[#F4845F]"
      style={{
        backgroundColor: IMAGES[activeIndex].bg,
        transition: 'background-color 650ms cubic-bezier(0.4, 0, 0.2, 1)',
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
      }}
    >
      <div className="relative w-full h-[100vh] overflow-hidden">
        {/* 1. Grain overlay - updated with higher opacity 0.12 z-[50] to match Artistic Flair theme */}
        <div
          id="grain-overlay"
          className="absolute inset-0 pointer-events-none opacity-[0.12]"
          style={{
            zIndex: 50,
            backgroundImage: grainBackground,
            backgroundSize: '200px 200px',
            backgroundRepeat: 'repeat',
          }}
        />

        {/* 2. Giant ghost text "3D SHAPE" - with Impact/Anton display style and top-[-10%] offset */}
        <div
          id="giant-ghost-text"
          className="absolute inset-0 flex items-center justify-center pointer-events-none select-none z-[2] top-[-10%]"
        >
          <h1
            className="text-white opacity-[0.15] leading-none uppercase whitespace-nowrap tracking-tighter font-anton"
            style={{
              fontSize: 'clamp(90px, 28vw, 380px)',
            }}
          >
            3D SHAPE
          </h1>
        </div>

        {/* 3. Top Left Brand label "TOONHUB" - with updated spacing and style */}
        <div
          id="brand-label"
          className="absolute top-8 left-8 z-[60] text-xs font-bold uppercase tracking-[0.2em] opacity-90 text-white select-none"
        >
          TOONHUB
        </div>

        {/* 4. Carousel Viewport/Items */}
        <div id="carousel-container" className="absolute inset-0 z-[10]">
          {IMAGES.map((image, index) => {
            const roleStyle = getRoleStyles(index);
            return (
              <div
                key={index}
                id={`carousel-item-${index}`}
                className="absolute"
                style={{
                  aspectRatio: '0.6 / 1',
                  ...roleStyle,
                }}
              >
                <img
                  src={image.src}
                  alt={`TOONHUB Character Figurine ${index + 1}`}
                  className="w-full h-full object-contain object-bottom select-none pointer-events-none"
                  draggable="false"
                  referrerPolicy="no-referrer"
                />
              </div>
            );
          })}
        </div>

        {/* 5. Bottom-left text + navigation buttons */}
        <div
          id="carousel-controls"
          className="absolute bottom-20 left-6 sm:left-24 z-[60] max-w-[320px] text-white flex flex-col justify-end"
        >
          <h2
            id="control-title"
            className="text-[22px] font-bold uppercase tracking-wider mb-3 leading-tight text-white"
          >
            TOONHUB FIGURINES
          </h2>
          <p
            id="control-description"
            className="hidden sm:block text-sm opacity-80 leading-relaxed mb-6 font-medium text-white"
          >
            The artwork is stunning, shipped fully prepared. The finish is a vision, the 3D craft is flawless. Many thanks! Wishing you the win. Order now.
          </p>
          <div id="navigation-buttons" className="flex gap-4">
            <button
              id="btn-prev"
              onClick={() => navigate('prev')}
              className="w-16 h-16 rounded-full border-2 border-white flex items-center justify-center hover:bg-white/10 transition-all duration-150 active:scale-95 cursor-pointer text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-transparent"
              aria-label="Previous figurine"
            >
              <ArrowLeft size={26} strokeWidth={2.25} />
            </button>
            <button
              id="btn-next"
              onClick={() => navigate('next')}
              className="w-16 h-16 rounded-full border-2 border-white flex items-center justify-center hover:bg-white/10 transition-all duration-150 active:scale-95 cursor-pointer text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-transparent"
              aria-label="Next figurine"
            >
              <ArrowRight size={26} strokeWidth={2.25} />
            </button>
          </div>
        </div>

        {/* 6. Bottom Right Discover */}
        <a
          id="discover-link"
          href="#discover"
          className="absolute bottom-20 right-10 z-[60] flex items-center gap-3 cursor-pointer group text-white no-underline focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-transparent rounded"
        >
          <span
            className="uppercase font-black leading-none tracking-tighter opacity-90 group-hover:opacity-100 transition-opacity font-anton text-3xl sm:text-5xl"
          >
            DISCOVER IT
          </span>
          <ArrowRight className="w-6 h-6 sm:w-8 sm:h-8 group-hover:translate-x-1 transition-transform" strokeWidth={2.25} />
        </a>
      </div>
    </div>
  );
}
